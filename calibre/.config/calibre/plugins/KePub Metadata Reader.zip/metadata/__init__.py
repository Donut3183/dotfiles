"""KePub metadata handling."""
