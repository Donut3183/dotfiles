__license__   = 'GPL v3'
__copyright__ = '2021, Wiso'
__docformat__ = 'restructuredtext en'

import os
import datetime
import sys
sys.path.append("./")
from calibre_plugins.AudioBook_Duration.unzip import UNZIP_PATH
from calibre.constants import plugins, iswindows, islinux, isosx

from calibre_plugins.AudioBook_Duration.unzip import install_libs
sys.path.append(UNZIP_PATH)
#print('En la ruta: ' + os.getcwd())
####
#print('En la ruta: ' + os.getcwd())
## Da error en windows porque necesito permisos admin
## Cambio el permisos de la libreria Calibre en AppData/Roaming/calibre
##
#
from calibre.utils.config import config_dir
import subprocess

try:
    os.chdir(UNZIP_PATH)
except:
    parent = config_dir
    trash = '.' + parent.split(os.sep)[-1]
    final_path = parent[:-len(trash)]
    #print('VOY A CAMBIAR LOS PERMISOS A LA CARPETA' + parent)
    retcode = subprocess.Popen(['icacls.exe', parent, '/reset', '/Q', '/T']).wait()
#
#print('En la ruta: ' + os.getcwd())

import mutagen
import rarfile

from mutagen.mp3 import MP3
from mutagen.mp4 import MP4
from mutagen.flac import FLAC
from mutagen.aac import AAC
from mutagen.ac3 import AC3
from mutagen.oggvorbis import OggVorbis
from calibre_plugins.AudioBook_Duration.config import prefs
from calibre.customize import FileTypePlugin
import zipfile
from calibre_plugins.AudioBook_Duration.unzip import Unrar_Tool

from rarfile.rarfile import RarFile
#from calibre.utils import unrar
if iswindows:
    rarfile.rarfile.UNRAR_TOOL = Unrar_Tool
## Ya he importado, salgo a otro path y salgo de los permisos de modo admin.

# function to convert the information into
# some readable format
def audio_duration(length):
    hours = length // 3600  # calculate in hours
    length %= 3600
    mins = length // 60  # calculate in minutes
    length %= 60
    seconds = length  # calculate in seconds

    return hours, mins, seconds  # returns the duration


def duration():
    return True


def audio_file_duration(filename, is_ziped=False, archive=0):
    print(filename)
    total_length = 0
    if is_ziped:
        print('is zipped')
        file = archive.open(filename)
        print('is zipped ok')
    else:
        file = filename
    #no haría falta el 1er if ya se comprueba antes de entrar a la funcion
    if filename.lower().endswith(('mp3', 'ogg', 'm4a', 'm4b', 'mp4', 'flac', 'aac', 'ac3')):
        print('Hay audios...')
        if filename.lower().endswith('mp3'):
            audio = MP3(file)
        if filename.lower().endswith('ogg'):
            audio = OggVorbis(file)
        if filename.lower().endswith(('m4a', 'm4b', 'mp4')):
            audio = MP4(file)
        if filename.lower().endswith('flac'):
            audio = FLAC(file)
        if filename.lower().endswith('aac'):
            audio = AAC(file)
        if filename.lower().endswith('ac3'):
            audio = AC3(file)
        #progress.setLabelText(filename)
        audio_info = audio.info
        length = int(audio_info.length)
        total_length += length
    #   hours, mins, seconds = audio_duration(length)
    #   print('Nombre: ' + filename + ' Duración: {}:{}:{}'.format(hours, mins, seconds))
        print('Nombre: ' + filename + ' Duración: ' + str(datetime.timedelta(seconds=length)))
    print('TOTAL archivo audio: ' + str(datetime.timedelta(seconds=total_length)) + '\n')
    return total_length

def check_zfile_duration(filename):
    is_ziped = True
    comprimido_ok = False
    total_length = 0
    print('Dentro del archivo comprimido... ' + filename)
    if filename.lower().endswith('zip'):
        print('Es un ZIP: ' + filename)
        archive = zipfile.ZipFile(filename)
        comprimido_ok = True
    if filename.lower().endswith('rar'):
        print('Es un RAR: ' + filename)
        archive = RarFile(filename)
        comprimido_ok = True
    if comprimido_ok:
        for zfilename in archive.namelist():
            if zfilename.lower().endswith(('mp3', 'ogg', 'm4a', 'm4b', 'mp4', 'flac', 'aac', 'ac3')):
                length = audio_file_duration(zfilename, is_ziped, archive)
                total_length += length
    print('TOTAL Compressed audio: ' + str(datetime.timedelta(seconds=total_length)) + '\n')
    return total_length


def check_duration(path, progress):
    # Recorro los archivos de la carpeta
    total_length = 0
    duration = ''
    #
    #filenames = next(os.walk("./", topdown=True))[2]
    filenames = next(os.walk(path, topdown=True))[2]
    sys.path.append(path)
    os.chdir(path)
    print('path: ' + path)
    for filename in filenames:
        length = 0
        if filename.lower().endswith(('mp3', 'ogg', 'm4a', 'm4b', 'mp4', 'flac', 'aac', 'ac3')):
            length = audio_file_duration(filename)
        if filename.lower().endswith(('zip', 'rar')):
            length = check_zfile_duration(filename)
        total_length += length
        # print('Dentro del for archivo... ' + filename)
        ###print('En la ruta: ' + os.getcwd())
        # if filename.lower().endswith(('mp3', 'ogg', 'm4a', 'm4b', 'mp4', 'flac', 'aac', 'ac3')):
            # print('Hay audios...')
            # if filename.lower().endswith('mp3'):
                # audio = MP3(filename)
            # if filename.lower().endswith('ogg'):
                # audio = OggVorbis(filename)
            # if filename.lower().endswith(('m4a', 'm4b', 'mp4')):
                # audio = MP4(filename)
            # if filename.lower().endswith('flac'):
                # audio = FLAC(filename)
            # if filename.lower().endswith('aac'):
                # audio = AAC(filename)
            # if filename.lower().endswith('ac3'):
                # audio = AC3(filename)
            ###progress.setLabelText(filename)
            # audio_info = audio.info
            # length = int(audio_info.length)
            # total_length += length
    ###        hours, mins, seconds = audio_duration(length)
    ###        print('Nombre: ' + filename + ' Duración: {}:{}:{}'.format(hours, mins, seconds))
            # print('Nombre: ' + filename + ' Duración: ' + str(datetime.timedelta(seconds=length)))
    #hours, mins, seconds = audio_duration(total_length)
    #print('Duración Total: {}:{}:{}'.format(hours, mins, seconds))
    hours, mins, seconds = audio_duration(total_length)
    print('Duración Total: {}:{}:{}'.format(hours, mins, seconds))
    # aqui#print('Duración Total: ' + str(datetime.timedelta(seconds=total_length)))
    duration = '%d:%02d:%02d' % (hours, mins, seconds)
    duration = str(duration)

    #duration = str(datetime.timedelta(seconds=total_length))
    return duration
#i=0
#while i < len(filenames):
#    print(filenames[1])
#    i +=1


# Create a WAVE object
# Specify the directory address of your wavpack file
# "alarm.wav" is the name of the audiofile
##audio = MP3("1.mp3")

# contains all the metadata about the wavpack file
##audio_info = audio.info
##length = int(audio_info.length)
##hours, mins, seconds = audio_duration(length)
##print('Total Duration: {}:{}:{}'.format(hours, mins, seconds))
